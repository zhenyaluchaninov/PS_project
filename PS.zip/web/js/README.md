# Textäventyr

## Architecture

This document outlines the architecture for the javascript webclient


### Storage

Storage's purpose is to store adventures in localStorage and to pass them to the server.

### Restclient

Restclient's purpose is to communicate with the server.
Its only purpose is to server Storage with serverside communication facilties.

### Model

Model is used to manipulate the model.
