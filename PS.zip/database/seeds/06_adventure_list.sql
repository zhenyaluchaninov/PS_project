INSERT INTO `adventure_list` (`id`, `title`, `description`, `created_at`, `updated_at`)
VALUES
  (1,'front','Äventyr som listas på startsidan','2019-03-11 13:46:18','0000-00-00 00:00:00'),
  (2,'archive','Äventyr som listas i arkivet','2019-03-11 13:46:18','0000-00-00 00:00:00');
