INSERT INTO `adventure_category` (`id`, `sort_order`, `title`, `description`, `icon`, `image`, `created_at`, `updated_at`)
VALUES
  (1,0,'- Ej kategoriserad -','Ingen kategori tilldelad','tag',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (2,1,'Deckare','','search',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (3,2,'Drama','','spider',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (4,3,'Fantasy','','dragon',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (5,4,'Komedi','','candy-cane',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (6,5,'Science fiction','','user-astronaut',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (7,6,'Skräck','','crow',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (8,7,'Thriller','','surprise',NULL,'2019-03-11 10:26:27','0000-00-00 00:00:00'),
  (9,8,'Projekt PS','','secret',NULL,'2021-03-18 16:41:27','0000-00-00 00:00:00');
