
INSERT INTO users (username, password) VALUES
("johanm", "$2a$14$A4b4oi97qLe8RzGNXH7vCOo9zJZKbQnExzlgAVzxO2n6xIDgHP95W"), /* alfabeta */
("novakb", "$2a$14$Zfgu9By1qyvQKqPdjMWtaecVWudQNRkPA.1QEsLQIumkUUPT85f5G"); /* gammadelta */
