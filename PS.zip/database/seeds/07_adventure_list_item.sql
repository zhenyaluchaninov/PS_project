INSERT INTO `adventure_list_item` (`list_id`, `adventure_id`, `ordinal`)
VALUES
  (1,15,1),
  (1,307,2),
  (1,481,3);
