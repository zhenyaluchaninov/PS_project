ALTER TABLE `adventure_node` CHANGE `content` `content` VARCHAR(10000) DEFAULT NULL;
