import React from "react";
import "./home.css";

const Dashboard = () => {
  return (
    <div className="container-fluid">
      <h1>Dashboard</h1>
    </div>
  );
}

export default Dashboard;
