import actions from "./actions"
import reducers from "./reducers"

const State = {
  actions,
  reducers
};

export default State
